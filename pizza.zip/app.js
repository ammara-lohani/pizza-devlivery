const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');

// Initialize Express App
const app = express();

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));  // Serve static files from public folder

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/pizzaStore', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Pizza Schema & Model
const pizzaSchema = new mongoose.Schema({
    base: String,
    sauce: String,
    cheese: String,
    veggies: [String],
    status: { type: String, default: 'Placed' }  // Status of the order
});

const Pizza = mongoose.model('Pizza', pizzaSchema);

// API Endpoints
// 1. Endpoint to place an order (for user)
app.post('/api/order', async (req, res) => {
    try {
        const { base, sauce, cheese, veggies } = req.body;
        const newOrder = new Pizza({ base, sauce, cheese, veggies });
        await newOrder.save();
        res.status(201).send({ message: 'Order placed successfully!' });
    } catch (error) {
        res.status(500).send({ message: 'Failed to place order' });
    }
});

// 2. Endpoint to get all orders (for admin)
app.get('/api/admin/orders', async (req, res) => {
    try {
        const orders = await Pizza.find();
        res.status(200).send(orders);
    } catch (error) {
        res.status(500).send({ message: 'Failed to fetch orders' });
    }
});

// Serve frontend HTML pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Start the server
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
